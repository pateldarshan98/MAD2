package com.example.customlistview

data class Fruit (val firstname: String, val secondname: String, val codename: String, val photo: String)